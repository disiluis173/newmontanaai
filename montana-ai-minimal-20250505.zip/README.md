# Montana AI (Versión Mínima)

Esta es una versión mínima del proyecto Montana AI que reduce significativamente el tamaño.

## Instalación

1. Asegúrate de tener Node.js instalado (versión 16 o superior)
2. Ejecuta el siguiente comando para instalar las dependencias:

\\\
npm install
\\\

## Ejecución

Para iniciar el servidor de desarrollo:

\\\
npm run dev
\\\

## API Keys

Necesitarás configurar tus API Keys para:
- DeepSeek AI (comienza con sk-...)
- X.AI / Grok (comienza con xai-...)

Estas se configuran directamente en la aplicación la primera vez que la ejecutes.
